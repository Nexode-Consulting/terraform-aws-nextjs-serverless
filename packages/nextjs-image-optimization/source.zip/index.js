"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_s3_1 = require("@aws-sdk/client-s3");
const sharp_1 = __importDefault(require("sharp"));
const constants_1 = require("./constants");
const helpers_1 = require("./helpers");
/**
 * This TypeScript function is a CloudFront function that resizes and compresses images based on the
 * request URI and returns the resized image as a base64 encoded string.
 * @param {any} event - The `event` parameter is an object that contains information about the event
 * that triggered the Lambda function. In this case, it contains the CloudFront event data, which
 * includes details about the request and configuration.
 * @param {any} _context - The `_context` parameter is a context object that contains information about
 * the execution environment and runtime. It is typically not used in this code snippet, so it can be
 * ignored for now.
 * @param {any} callback - The `callback` parameter is a function that is used to send the response
 * back to the caller. It takes two arguments: an error object (or null if there is no error) and the
 * response object. The response object should contain the status code, status description, headers,
 * body encoding, and
 * @returns The code is returning a response object with the following properties:
 */
const handler = (event, _context, callback) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q;
    try {
        /* Extract the `request` and `config` properties. */
        const { request, config } = (_b = (_a = event === null || event === void 0 ? void 0 : event.Records) === null || _a === void 0 ? void 0 : _a[0]) === null || _b === void 0 ? void 0 : _b.cf;
        /* Construct the base URL for the image assets. */
        const baseUrl = (config === null || config === void 0 ? void 0 : config.distributionDomainName) + '/assets/';
        /* The S3 region. */
        const s3Region = (_g = (_f = (_e = (_d = (_c = request === null || request === void 0 ? void 0 : request.origin) === null || _c === void 0 ? void 0 : _c.custom) === null || _d === void 0 ? void 0 : _d.customHeaders) === null || _e === void 0 ? void 0 : _e['S3-region']) === null || _f === void 0 ? void 0 : _f[0]) === null || _g === void 0 ? void 0 : _g.value;
        /* The public_assets_bucket name. */
        const publicAssetsBucket = (_m = (_l = (_k = (_j = (_h = request === null || request === void 0 ? void 0 : request.origin) === null || _h === void 0 ? void 0 : _h.custom) === null || _j === void 0 ? void 0 : _j.customHeaders) === null || _k === void 0 ? void 0 : _k['public-assets-bucket']) === null || _l === void 0 ? void 0 : _l[0]) === null || _m === void 0 ? void 0 : _m.value;
        /* Extracting the relevant information from the request URI. */
        const queryString = (_p = (_o = request === null || request === void 0 ? void 0 : request.uri) === null || _o === void 0 ? void 0 : _o.replace('/_next/image/', '')) === null || _p === void 0 ? void 0 : _p.split('/');
        // Build an object with these information
        const query = {
            width: parseInt((queryString === null || queryString === void 0 ? void 0 : queryString[0]) || constants_1.defaults.width.toString()),
            quality: parseInt((queryString === null || queryString === void 0 ? void 0 : queryString[1]) || constants_1.defaults.quality.toString()),
            type: 'image/' + (queryString === null || queryString === void 0 ? void 0 : queryString[2]),
            filename: (_q = queryString === null || queryString === void 0 ? void 0 : queryString.slice(3)) === null || _q === void 0 ? void 0 : _q.join('/'),
        };
        // The url where the image is stored
        const imageUrl = 'https://' + baseUrl + query.filename;
        // The options for image transformation
        const options = {
            quality: query.quality,
        };
        /* The S3 Client. */
        const s3 = new client_s3_1.S3Client({ region: s3Region });
        /* Build the s3 command. */
        const s3Command = new client_s3_1.GetObjectCommand({
            Bucket: publicAssetsBucket,
            Key: 'assets/' + query.filename.replace('%2F', '/'),
        });
        /* The body of the S3 object. */
        const { Body } = yield s3.send(s3Command);
        /* Transforming the body of the S3 object into a byte array. */
        const s3Object = yield Body.transformToByteArray();
        /* Resize and compress the image. */
        const resizedImage = (0, sharp_1.default)(s3Object).resize({ width: query.width });
        let newContentType = null;
        /* Apply the corresponding image type transformation. */
        switch (query.type) {
            case 'image/webp':
                resizedImage.webp(options);
                newContentType = 'image/webp';
                break;
            case 'image/jpeg':
                resizedImage.jpeg(options);
                newContentType = 'image/jpeg';
                break;
            case 'image/png':
                resizedImage.png(options);
                newContentType = 'image/png';
                break;
            // case 'image/gif':
            //   // resizedImage.gif(options)
            //   resizedImage.gif()
            //   newContentType = 'image/gif'
            //   break
            // case 'image/apng':
            //   // resizedImage.apng(options)
            //   resizedImage.png(options)
            //   newContentType = 'image/apng'
            //   break
            // case 'image/avif':
            //   resizedImage.avif(options)
            //   newContentType = 'image/avif'
            //   break
            // // case 'image/svg+xml':
            // //   resizedImage.svg(options)
            // //   newContentType = 'image/svg+xml'
            // //   break
            default:
                return (0, helpers_1.redirectTo)(imageUrl, callback);
        }
        /* Converting the resized image into a buffer. */
        const resizedImageBuffer = yield resizedImage.toBuffer();
        /* The response body in the CloudFront function is expected to be a base64 encoded string. */
        const imageBase64 = resizedImageBuffer.toString('base64');
        /* If the resized image exceeds the Cloudfront response size limit, redirect to the original image */
        if (imageBase64.length > constants_1.limits.imageSize) {
            return (0, helpers_1.redirectTo)(imageUrl, callback);
        }
        /* Define the response. */
        const response = {
            status: 200,
            statusDescription: 'OK',
            headers: {
                'content-type': [
                    {
                        key: 'Content-Type',
                        value: newContentType,
                    },
                ],
                'cache-control': [
                    {
                        key: 'Cache-Control',
                        value: 'public, max-age=600, stale-while-revalidate=2592000', // Serve cached content up to 30 days old while revalidating it after 10 minutes
                    },
                ],
            },
            bodyEncoding: 'base64',
            body: imageBase64,
        };
        return callback(null, response);
    }
    catch (error) {
        console.error({ error });
        return callback(null, {
            status: 403, // to not leak data
        });
    }
});
exports.handler = handler;
