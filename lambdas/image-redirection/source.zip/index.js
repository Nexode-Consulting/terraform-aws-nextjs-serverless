"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
/* A list of supported image types.
It contains the MIME types for various image formats.
These image types are prioritized in the array, with the most preferred format at the beginning. */
const imageTypes = [
    'image/webp',
    'image/avif',
    'image/jpeg',
    'image/png',
    'image/svg+xml',
    'image/gif',
    'mage/apng',
];
const handler = (event, _context, callback) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c, _d, _e, _f, _g, _h;
    try {
        /* Extract the `request` properties. */
        const request = (_c = (_b = (_a = event === null || event === void 0 ? void 0 : event.Records) === null || _a === void 0 ? void 0 : _a[0]) === null || _b === void 0 ? void 0 : _b.cf) === null || _c === void 0 ? void 0 : _c.request;
        /* This forms the base URL for the redirect. */
        const baseUrl = '/_next/image';
        /* Parsing the query string from the request URL and converting it into an object. */
        const query = (_d = request === null || request === void 0 ? void 0 : request.querystring) === null || _d === void 0 ? void 0 : _d.split('&').map((q) => q.split('=')).reduce((acc, q) => (Object.assign(Object.assign({}, acc), { [q[0]]: q[1] })), {});
        /* Extract the value of the "accept" header from the request headers. */
        const acceptHeader = (_g = (_f = (_e = request === null || request === void 0 ? void 0 : request.headers) === null || _e === void 0 ? void 0 : _e.accept) === null || _f === void 0 ? void 0 : _f.find((item) => item.key === 'accept')) === null || _g === void 0 ? void 0 : _g.value;
        /* Create a list with accepted image types. */
        const acceptedTypes = (_h = acceptHeader === null || acceptHeader === void 0 ? void 0 : acceptHeader.split(',')) === null || _h === void 0 ? void 0 : _h.filter((type) => type.startsWith('image/'));
        /* Default value in case none of the accepted image types match the supported image types. */
        let requestType = imageTypes[0];
        /* Find a prefered type that is accepted */
        for (const type of imageTypes) {
            if (acceptedTypes.includes(type)) {
                requestType = type;
                break;
            }
        }
        /*  Creating a URL string for the redirect. */
        const redirectToUrl = [
            baseUrl,
            query === null || query === void 0 ? void 0 : query.w,
            query === null || query === void 0 ? void 0 : query.q,
            requestType.replace('image/', ''),
            query === null || query === void 0 ? void 0 : query.url.replace('%2F', ''),
        ].join('/');
        /* Define the response. */
        const response = {
            status: 302,
            statusDescription: 'Redirect',
            headers: {
                location: [
                    {
                        key: 'Location',
                        value: redirectToUrl,
                    },
                ],
            },
        };
        return callback(null, response);
    }
    catch (error) {
        console.error({ error });
        return callback(null, {
            status: 403, // to not leak data
        });
    }
});
exports.handler = handler;
