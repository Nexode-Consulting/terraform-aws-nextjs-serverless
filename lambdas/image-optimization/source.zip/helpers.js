"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.redirectTo = exports.fetchBufferFromUrl = void 0;
const https_1 = __importDefault(require("https"));
/**
 * The function fetchBufferFromUrl fetches a buffer from a given URL using the https module in Node.js.
 * @param {string} url - The `url` parameter is a string that represents the URL from which you want to
 * fetch the buffer.
 * @returns The function `fetchBufferFromUrl` returns a Promise that resolves to a Buffer.
 */
const fetchBufferFromUrl = (url) => {
    return new Promise((resolve, reject) => {
        https_1.default.get(url, res => {
            const chunks = [];
            res.on('data', chunk => {
                chunks.push(chunk);
            });
            res.on('end', () => {
                const buffer = Buffer.concat(chunks);
                resolve(buffer);
            });
            res.on('error', error => {
                reject(error);
            });
        });
    });
};
exports.fetchBufferFromUrl = fetchBufferFromUrl;
/**
 * The function `redirectTo` is used to create a redirect response with a specified URL.
 * @param {string} url - The `url` parameter is a string that represents the URL to which you want to
 * redirect the user.
 * @param {any} callback - The `callback` parameter is a function that is used to return the response
 * to the caller. It takes two arguments: an error object (if any) and the response object. In this
 * case, the response object is an HTTP response with a status code of 302 (Redirect) and a `
 * @returns a callback function with two arguments: null and an object representing a response.
 */
const redirectTo = (url, callback) => {
    const response = {
        status: 302,
        statusDescription: 'Redirect',
        headers: {
            location: [
                {
                    key: 'Location',
                    value: url,
                },
            ],
        },
    };
    return callback(null, response);
};
exports.redirectTo = redirectTo;
