"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.limits = exports.defaults = void 0;
exports.defaults = {
    width: 200,
    quality: 80,
};
exports.limits = {
    imageSize: 1024 * 1024
};
