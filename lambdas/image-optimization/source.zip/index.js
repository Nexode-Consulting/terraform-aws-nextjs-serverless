"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const constants_1 = require("./constants");
const helpers_1 = require("./helpers");
const sharp_1 = __importDefault(require("sharp"));
/**
 * This TypeScript function is a CloudFront function that resizes and compresses images based on the
 * request URI and returns the resized image as a base64 encoded string.
 * @param {any} event - The `event` parameter is an object that contains information about the event
 * that triggered the Lambda function. In this case, it contains the CloudFront event data, which
 * includes details about the request and configuration.
 * @param {any} _context - The `_context` parameter is a context object that contains information about
 * the execution environment and runtime. It is typically not used in this code snippet, so it can be
 * ignored for now.
 * @param {any} callback - The `callback` parameter is a function that is used to send the response
 * back to the caller. It takes two arguments: an error object (or null if there is no error) and the
 * response object. The response object should contain the status code, status description, headers,
 * body encoding, and
 * @returns The code is returning a response object with the following properties:
 */
const handler = (event, _context, callback) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c, _d, _e;
    try {
        /* Extract the `request` and `config` properties. */
        const { request, config } = (_b = (_a = event === null || event === void 0 ? void 0 : event.Records) === null || _a === void 0 ? void 0 : _a[0]) === null || _b === void 0 ? void 0 : _b.cf;
        /* Construct the base URL for the image assets. */
        const baseUrl = (config === null || config === void 0 ? void 0 : config.distributionDomainName) + '/assets/';
        /* Extracting the relevant information from the request URI. */
        const queryString = (_d = (_c = request === null || request === void 0 ? void 0 : request.uri) === null || _c === void 0 ? void 0 : _c.replace('/_next/image/', '')) === null || _d === void 0 ? void 0 : _d.split('/');
        const query = {
            width: parseInt((queryString === null || queryString === void 0 ? void 0 : queryString[0]) || constants_1.defaults.width.toString()),
            quality: parseInt((queryString === null || queryString === void 0 ? void 0 : queryString[1]) || constants_1.defaults.quality.toString()),
            type: 'image/' + (queryString === null || queryString === void 0 ? void 0 : queryString[2]),
            filename: (_e = queryString === null || queryString === void 0 ? void 0 : queryString.slice(3)) === null || _e === void 0 ? void 0 : _e.join('/'),
        };
        const options = {
            quality: query.quality,
        };
        // The url where the image is stored
        const imageUrl = 'https://' + baseUrl + query.filename;
        /* Fetching the image data and returning them as a
        buffer. */
        const buffer = yield (0, helpers_1.fetchBufferFromUrl)(imageUrl);
        /* Resize and compress the image. */
        const resizedImage = (0, sharp_1.default)(buffer).resize({ width: query.width });
        let newContentType = null;
        /* Apply the corresponding image type transformation. */
        switch (query.type) {
            case 'image/webp':
                resizedImage.webp(options);
                newContentType = 'image/webp';
                break;
            case 'image/jpeg':
                resizedImage.jpeg(options);
                newContentType = 'image/jpeg';
                break;
            case 'image/png':
                resizedImage.png(options);
                newContentType = 'image/png';
                break;
            // case 'image/gif':
            //   // resizedImage.gif(options)
            //   resizedImage.gif()
            //   newContentType = 'image/gif'
            //   break
            // case 'image/apng':
            //   // resizedImage.apng(options)
            //   resizedImage.png(options)
            //   newContentType = 'image/apng'
            //   break
            // case 'image/avif':
            //   resizedImage.avif(options)
            //   newContentType = 'image/avif'
            //   break
            // // case 'image/svg+xml':
            // //   resizedImage.svg(options)
            // //   newContentType = 'image/svg+xml'
            // //   break
            default:
                return (0, helpers_1.redirectTo)(imageUrl, callback);
        }
        /* Converting the resized image into a buffer. */
        const resizedImageBuffer = yield resizedImage.toBuffer();
        /* The response body in the CloudFront function is expected to be a base64 encoded string. */
        const imageBase64 = resizedImageBuffer.toString('base64');
        /* If the resized image exceeds the Cloudfront response size limit, redirect to the original image */
        if (imageBase64.length > constants_1.limits.imageSize) {
            return (0, helpers_1.redirectTo)(imageUrl, callback);
        }
        /* Define the response. */
        const response = {
            status: 200,
            statusDescription: 'OK',
            headers: {
                'content-type': [
                    {
                        key: 'Content-Type',
                        value: newContentType,
                    },
                ],
                'cache-control': [
                    {
                        key: 'Cache-Control',
                        value: 'public, max-age=600, stale-while-revalidate=2592000', // Serve cached content up to 30 days old while revalidating it after 10 minutes
                    },
                ],
            },
            bodyEncoding: 'base64',
            body: imageBase64,
        };
        return callback(null, response);
    }
    catch (error) {
        console.error({ error });
        return callback(null, {
            status: 403, // to not leak data
        });
    }
});
exports.handler = handler;
